
R = 200;
D = 2*R; %the diameter of the decision set
G_norm = 2*R+sqrt(n); %the upper bound of the gradient norm

eta = D/(sqrt(2)*G_norm*(T/max_delay+2)^(3/4)); %according to our Theorem 1

%Initialization
x = ones(n,1);
x = (R.*x)./sum(x);
x_1 = x;

X = zeros(n,max_delay+1);
is_free = zeros(max_delay+1,1);
for i = 1:max_delay+1
    X(:,i) = x_1;
end
G = zeros(n,max_delay+1);

loss = zeros(T,1);

for i = 1:T
    b = B(i,:)';
    base_id = 1;
    while is_free(base_id) ~= 0
            base_id = base_id + 1;
    end
    x = X(:,base_id);
    is_free(base_id) = delay(i,1);
    
    loss(i) = x'*x + b'*x;
    G(:,base_id) = G(:,base_id) + 2.*x + b;
    DF = eta.*G(:,base_id) + 2.*(x - x_1);
    %linear optimization
    [~,index] = max(abs(DF));
    v = zeros(n,1);
    v(index) = sign(-DF(index))*R;
    delta = v - x;
    sigma = min(-0.5*delta'*DF/(delta'*delta),1); %Line Search
    X(:,base_id) = (1 - sigma).*x + sigma.*v;
    
    for iner_id = 1:max_delay+1
        if is_free(iner_id) > 0
            is_free(iner_id) = is_free(iner_id) - 1;
        end
    end
end
