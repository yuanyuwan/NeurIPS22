
# Description
The package includes the codes used in the paper titled "Online Frank-Wolfe with Arbitrary Delays".

# How to run?
1.Run main_exp.m for the result shown in Figure 1.

# Other Specific Functions
gen_data.m -> The function utilized to generate the synthetic data.
D_OFW.m -> Algorithm 1 proposed in our paper.
D_SC_OFW.m -> Algorithm 2 proposed in our paper.
BOLD_OFW.m -> The combination of BOLD in the paper titled "Online learning under delayed feedback" and OFW for convex losses.
BOLD_SC_OFW.m -> The combination of BOLD in the paper titled "Online learning under delayed feedback" and OFW for strongly convex losses.
createfigure1.m -> The function utilized to generate Figure 1(a).
createfigure2.m -> The function utilized to generate Figure 1(b).



