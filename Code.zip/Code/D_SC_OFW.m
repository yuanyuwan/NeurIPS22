

R = 200;

%Initialization
x = ones(n,1);
x = (R.*x)./sum(x);
x_1 = x;
loss = zeros(T,1);
G = zeros(n,1);
rec_G = zeros(n,T); % gradient buffer
tau = 1;
xs = zeros(n,1);

for i = 1:T
    b = B(i,:)';
    loss(i) = x'*x + b'*x;
    rec_G(:,i) = 2.*x + b;
    for iner_iter = max(1,i-max_delay):1:i
        if iner_iter + delay(iner_iter) - 1 == i
            G = G + rec_G(:,iner_iter);
            xs = xs + 2.*x;
            DF = G + 2*tau.*x - xs;
            %linear optimization
            [~,index] = max(abs(DF));
            v = zeros(n,1);
            v(index) = sign(-DF(index))*R;
            delta = v - x;
            sigma = min(-0.5*delta'*DF/(tau*(delta'*delta)),1); %Line Search
            x = (1 - sigma).*x + sigma.*v;
            tau = tau + 1;
        end
    end
end

