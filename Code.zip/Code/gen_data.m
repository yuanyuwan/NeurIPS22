
rng(1)

T=10000;
n=1000;
B = zeros(T,n);

for i = 1:T
    B(i,:) = 2.*rand(1,n) - 1;
end

save('syn_data.mat', 'B')
