
R = 200;
D = 2*R; %the diameter of the decision set
G_norm = 2*R+sqrt(n); %the upper bound of the gradient norm
eta = D/(sqrt(2)*G_norm*(T+2)^(3/4)); %according to our Theorem 1

%Initialization
x = ones(n,1);
x = (R.*x)./sum(x);
x_1 = x;
loss = zeros(T,1);
G = zeros(n,1);
rec_G = zeros(n,T); % gradient buffer


for i = 1:T
    b = B(i,:)';
    loss(i) = x'*x + b'*x;
    rec_G(:,i) = 2.*x + b;
    for iner_iter = max(1,i-max_delay):1:i
        if iner_iter + delay(iner_iter) - 1 == i
            G = G + rec_G(:,iner_iter);
            DF = eta.*G + 2.*(x - x_1);
            %linear optimization
            [~,index] = max(abs(DF));
            v = zeros(n,1);
            v(index) = sign(-DF(index))*R;
            delta = v - x;
            sigma = min(-0.5*delta'*DF/(delta'*delta),1); %Line Search
            x = (1 - sigma).*x + sigma.*v;
        end
    end
end
