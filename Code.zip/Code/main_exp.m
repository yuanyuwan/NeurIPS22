
gen_data;

rng(0)

for max_delay = 1:50:501
    %Load Data
    load('./syn_data');
    [T,n] = size(B);
    
    delay = ceil(0.1*max_delay).*ones(T,1)-1+randi(max_delay-ceil(0.1*max_delay)+1,T,1);
    
    D_OFW;
    save(strcat('./results/',strcat(int2str(max_delay),'_dofw.mat')),'loss');
    
    BOLD_OFW;
    save(strcat('./results/',strcat(int2str(max_delay),'_bold_dofw.mat')),'loss');
    
    D_SC_OFW;
    save(strcat('./results/',strcat(int2str(max_delay),'_sc_dofw.mat')),'loss');
    
    BOLD_SC_OFW;
    save(strcat('./results/',strcat(int2str(max_delay),'_bold_sc_dofw.mat')),'loss');
    
    clear;
end

%%

%Figure 1(a)
cum_loss_dofw = zeros(1,11);
cum_bold_dofw = zeros(1,11);

for max_delay = 1:50:501
    load(strcat('./results/',strcat(int2str(max_delay),'_dofw.mat')));
    cum_loss_dofw(ceil(max_delay/50)) = sum(loss);
    
    load(strcat('./results/',strcat(int2str(max_delay),'_bold_dofw.mat')));
    cum_bold_dofw(ceil(max_delay/50)) = sum(loss);
end

x = 1:50:501;

cum_loss_sc_dofw = zeros(1,11);
cum_bold_sc_dofw = zeros(1,11);

for max_delay = 1:50:501
    load(strcat('./results/',strcat(int2str(max_delay),'_sc_dofw.mat')));
    cum_loss_sc_dofw(ceil(max_delay/50)) = sum(loss);
    
    load(strcat('./results/',strcat(int2str(max_delay),'_bold_sc_dofw.mat')));
    cum_bold_sc_dofw(ceil(max_delay/50)) = sum(loss);
end

createfigure1(x', [cum_loss_dofw;cum_bold_dofw;cum_loss_sc_dofw;cum_bold_sc_dofw])

%%
%Figure 1(b)
YMatrix1 = [];

load('./results/501_dofw.mat');
YMatrix1 = [YMatrix1,cumsum(loss)];

load('./results/501_bold_dofw.mat');
YMatrix1 = [YMatrix1,cumsum(loss)];

load('./results/501_sc_dofw.mat');
YMatrix1 = [YMatrix1,cumsum(loss)];

load('./results/501_bold_sc_dofw.mat');
YMatrix1 = [YMatrix1,cumsum(loss)];

createfigure2(YMatrix1)

