
R = 200;

%Initialization
x = ones(n,1);
x = (R.*x)./sum(x);
x_1 = x;

X = zeros(n,max_delay+1);
is_free = zeros(max_delay+1,1);
for i = 1:max_delay+1
    X(:,i) = x_1;
end
G = zeros(n,max_delay+1);
xs = zeros(n,max_delay+1);
tau = ones(max_delay+1,1);

loss = zeros(T,1);

for i = 1:T
    b = B(i,:)';
    base_id = 1;
    while is_free(base_id) ~= 0
            base_id = base_id + 1;
    end
    x = X(:,base_id);
    is_free(base_id) = delay(i,1);
    
    loss(i) = x'*x + b'*x;
    G(:,base_id) = G(:,base_id) + 2.*x + b;
    xs(:,base_id) = xs(:,base_id) + 2.*x;
    DF = G(:,base_id) + 2*tau(base_id,1).*x - xs(:,base_id);
    %linear optimization
    [~,index] = max(abs(DF));
    v = zeros(n,1);
    v(index) = sign(-DF(index))*R;
    delta = v - x;
    sigma = min(-0.5*delta'*DF/(tau(base_id,1)*(delta'*delta)),1); %Line Search
    X(:,base_id) = (1 - sigma).*x + sigma.*v;
    tau(base_id,1) = tau(base_id,1) + 1;
    
    for iner_id = 1:max_delay+1
        if is_free(iner_id) > 0
            is_free(iner_id) = is_free(iner_id) - 1;
        end
    end
end
